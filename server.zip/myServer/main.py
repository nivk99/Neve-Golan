from typing import Union

# import db
# from fastapi import FastAPI
import firebase_admin
from fastapi import FastAPI
from firebase_admin import credentials
from firebase_admin import db

#כדי להריץ תשרת לכתוב בטרמינל-  uvicorn main:app --reload  #

app = FastAPI()

cred = credentials.Certificate('neve-golan-firebase-adminsdk-easo0-1c50d1a21a.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://neve-golan-default-rtdb.firebaseio.com'
})

# add activity
@app.get("/addActivity/{name}/{timeStart}/{timeEnd}/{id}/{year}/{month}/{day}")
def read_root(name: str, timeStart: str, timeEnd: str, id: str,year: str,month: str,day: str):
    address="activity/"+year+'/'+month+'/'+day+'/'+name+','+timeStart+','+timeEnd
    ref = db.reference(address)
    print('start function')

    check_activity=ref.get()
    if check_activity != None : ## activity already exist
        return 'הפעילות כבר קיימת'
    print('out iff')


    activity = {
        'id': id,
        'name': name,
        'timeEnd': timeEnd,
        'timeStart': timeStart
    }
    print('first',address)
    ref.set(activity)

    print('set activity: ',address)
    return 'הפעילות הוספה'



#delet the activity
@app.get("/deleteActivity/{year}/{month}/{day}/{key}")
def read_root(year: str, month: str, day: str, key: str):

    address = "activity/" + year + '/' + month + '/' + day + '/' + key
    ref = db.reference(address)

    check_activity=ref.get()
    if check_activity == None : ## alredy delete
        return 'הפעילות כבר נמחקה מהמערכת'


    ref.delete()
    print('delete : '+address)

    return 'הפעילות נמחקה'





#@app.get("/a/{name}")
#def read_root(name: str):
 #   return 'hello'


# @app.get("/updateActivity/{name}/{timeStart}/{timeEnd}/{id}/{year}/{month}/{day}")
# def read_root(name: str, timeStart: str, timeEnd: str, id: str,year: str,month: str,day: str):
#     address="activity/"+year+'/'+month+'/'+day+'/'+name+','+timeStart+','+timeEnd
#     ref = db.reference(address)
#     print('start function')
#
#     check_activity=ref.get()
#     if check_activity == None : ## activity not exist
#         return 'הפעילות לא קיימת'
#
#     ref.set(None)
#
#     activity = {
#         'id': id,
#         'name': name,
#         'timeEnd': timeEnd,
#         'timeStart': timeStart
#     }
#     print('first',address)
#     ref.set(activity)
#
#     print('set activity: ',address)
#     return 'הפעילות הוספה'



# activity_ref = db.reference('activity/2023/1/8/none,3:35,23:35')
# activity = activity_ref.get()
# if activity==None :
#     print(0)
# else:
#     activity["id"] = "new_id"
#     activity_ref.set(activity)

